""""
Description: A class to manage LibraryItem objects.
Author: {Student Name}
Date: {Date}
"""
