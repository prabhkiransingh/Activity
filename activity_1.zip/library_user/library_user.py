""""
Description: A class to manage User objects.
Author: {Student Name}
Date: {Date}
"""
