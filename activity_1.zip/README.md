# Intermediate Software Development Activity Project
This project will be developed over the course of several activities.  Each 
activity will help to reinforce the knowledge gained in the module.

## Author
[Your name]

## Activity
Activity 1: Classes and Encapsulation.
Activity 2: Abstraction, Inheritance and Polymorphism.
Activity 3: Design Patterns.
Activity 4: Programming Paradigms.
Activity 5: Help Files and Installers.
